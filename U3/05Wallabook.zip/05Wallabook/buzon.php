<?php
require_once 'cabecera.php';
echo '<h4>Buzón</h4>';
require_once 'pie.php';
?>